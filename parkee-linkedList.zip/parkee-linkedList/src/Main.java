public class Main {
    public static void main(String[] args) {
        SingleLinkedList list = new SingleLinkedList();
        list.insertAtBeggining(3);
        list.insertAtBeggining(2);
        list.insertAtBeggining(2);
        list.deleteByValue(3);
        list.insertAtEnd(3);
        list.insertAtEnd(6);
        list.display();
    }
}